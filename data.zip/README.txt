
SAILS Online data dump
======================

Data of SAILS Online is published under the following license:
http://creativecommons.org/licenses/by-nc-nd/2.0/de/deed.en

It should be cited as

Hammarstrom, Harald (eds.) 2014.
Dataset on Typological Features for South American Languages, collected 2009-2013 in the Traces of Contact Project (ERC Advanced Grant 230310) awarded to Pieter Muysken, Radboud Universiteit, Nijmegen, the Netherlands..
Leipzig: Max Planck Institute for Evolutionary Anthropology.
(Available online at http://sails.clld.org, Accessed on 2015-07-23.)


This package contains files in csv format [1] with corresponding schema
descriptions according to [2], representing rows in database tables of
the SAILS Online web application [3,4].

[1] http://www.w3.org/TR/tabular-data-model/#syntax
[2] http://www.w3.org/TR/tabular-metadata/
[3] http://sails.clld.org
[4] https://github.com/clld/SAILS
